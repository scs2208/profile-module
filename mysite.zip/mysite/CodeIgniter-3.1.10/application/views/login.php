<!DOCTYPE html>
<html>
<head>
<title>Login form</title>
</head>

<style type="text/css">
  .table{
    margin-top: 100px;
  }
  .name{
    font-size: 20px;
    font-weight: bold;
    color: blue;
  }
</style>
<body>
  <form method="post" class="table">
<table width="600" align="center" border="1" cellspacing="5" cellpadding="5">
 <tr>
    <td colspan="2"></td>
  </tr>
  <tr>
    <td class="name">Enter your Username </td>
    <td><input type="text" name="username"/></td>
 </tr>
  
 <tr>
    <td width="230" class="name">Enter Your Password </td>
    <td width="329"><input type="text" name="password"/></td>
  </tr> 
   <tr>
    <td colspan="2" align="center">
  <input type="submit"  name="login" value="Login"/></td>
  </tr>
</table>

  </form>
</body>
</html>












     



     



     



     


     


     





